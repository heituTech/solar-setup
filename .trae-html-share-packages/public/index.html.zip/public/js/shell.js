(function () {
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebarBackdrop');
  const menuBtn = document.getElementById('menuBtn');
  const closeBtn = document.getElementById('sidebarClose');

  function openSidebar() {
    sidebar.classList.add('open');
    backdrop.classList.add('show');
    menuBtn.setAttribute('aria-expanded', 'true');
    sidebar.setAttribute('aria-hidden', 'false');
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    backdrop.classList.remove('show');
    menuBtn.setAttribute('aria-expanded', 'false');
    sidebar.setAttribute('aria-hidden', 'true');
  }

  if (sidebar && backdrop && menuBtn) {
    menuBtn.addEventListener('click', openSidebar);
    if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
    backdrop.addEventListener('click', closeSidebar);
  }

  /* ===================== Language picker (opens upward) ===================== */
  const LANG_NAMES = { km: 'ខ្មែរ', en: 'English', zh: '中文' };
  const langBtn = document.getElementById('langCurrentBtn');
  const langMenu = document.getElementById('langMenu');
  const langLabel = document.getElementById('langCurrentLabel');

  function closeLangMenu() {
    if (!langMenu || !langBtn) return;
    langMenu.hidden = true;
    langBtn.setAttribute('aria-expanded', 'false');
  }

  window.updateLangPicker = function (lang) {
    if (langLabel) langLabel.textContent = LANG_NAMES[lang] || LANG_NAMES.en;
    if (!langMenu) return;
    langMenu.querySelectorAll('.lang-option').forEach(function (opt) {
      const selected = opt.dataset.lang === lang;
      opt.classList.toggle('active', selected);
      opt.setAttribute('aria-selected', selected ? 'true' : 'false');
    });
  };

  if (langBtn && langMenu) {
    langBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (langMenu.hidden) {
        langMenu.hidden = false;
        langBtn.setAttribute('aria-expanded', 'true');
      } else {
        closeLangMenu();
      }
    });

    langMenu.addEventListener('click', function (e) {
      const opt = e.target.closest('.lang-option');
      if (!opt) return;
      closeLangMenu();
      document.dispatchEvent(new CustomEvent('lang:change', { detail: { lang: opt.dataset.lang } }));
    });

    document.addEventListener('click', function (e) {
      if (!langMenu.hidden && !e.target.closest('.lang-picker')) closeLangMenu();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeLangMenu();
        if (sidebar && backdrop && menuBtn) closeSidebar();
      }
    });
  }
})();
